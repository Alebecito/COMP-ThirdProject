A Simple Hashtable in C
=======================

* Linked-list based chaining for dealing with collisions.
* Murmur as the internal hashing mechanism (good performance, good collision stats).
* BSD 2-clause license.

For a pretty straightforward example of how to use, see main.c.

All dependencies are included.
