#include<stdio.h>
#include<math.h> // math support some mathemetics inbuilt function
int power(int a, int b)
{
    int i=1;
     int p; //declaring p 
     while(i!=b){
          p *=a; //calculating power (a,b) and storing in 'p'
          return p; //returning power value to main funtion 
  

   
     }
}