#include<stdio.h>

int multiplication(int a,int b)
{
    return (a*b);    //returning  result to main funtion 
}