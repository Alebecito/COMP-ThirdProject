#include<stdio.h>
int subtraction(int a, int b)
{ 
    return (a-b); //returning  result to main funtion 
} 